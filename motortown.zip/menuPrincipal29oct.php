
<?php
    $servername = "127.0.0.1";
    $database = "motortown";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); 

    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
        
        $query = "select * from autoactualizado where id < 100";
        $resultado=mysqli_query($conexion, $query);
    }

    

    ?>
        

<center> <!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./menuPrincipalstyle_actualizadoFooter.css">
<meta charset="UTF-8">
    
<div id="preloader">
    <img src="imagenes/logomotortownsinfondo.png" alt="Imagen de introducción" id="intro-image">
  </div>


<title>Menu Principal</title>
    
    </head>

        <body>

    <header>
        <img src="./imagenes/logomotortownsinfondo.png"  height="100" length="auto">
                    <nav class="nav-left">
                <a href="http://localhost/iniciar_sesion29oct.php">Iniciar sesión</a>
                <a href="http://localhost/crear_cuenta.php">Registrarse</a>
            </nav>
        </div>
    </header>

    
    <div class="gradient-background"></div>
       
        <div class="ui-input-container">
            <input
              required=""
              placeholder="Buscar..."
              class="ui-input"
              type="text"
              id="searchInput"
              onkeyup="filterCards()"
            />
            <div class="ui-input-underline"></div>
            <div class="ui-input-highlight"></div>
            <div class="ui-input-icon">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <path
                  stroke-linejoin="round"
                  stroke-linecap="round"
                  stroke-width="2"
                  stroke="currentColor"
                  d="M21 21L16.65 16.65M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 3 6.58172 11 3C15.4183 3 19 6.58172 19 11Z"
                ></path>
              </svg>
            </div>
          </div>
          

          

          <script>
            //BUSCADOR
            
            function filterCards() {
  let input = document.getElementById("searchInput").value.toLowerCase();
  let cards = document.querySelectorAll(".card");
  
   
  let hasMatches = false;

  cards.forEach(card => {
    let title = card.querySelector(".card-title").textContent.toLowerCase();
    
    if (title.includes(input)) {
      card.style.display = "block"; 
      hasMatches = true;  
    } else {
      card.style.display = "none"; 
    }
  });

 
  if (input === "") {
    cards.forEach(card => {
      card.style.display = "block";  
    });
  }
}

                //PRELOADER
    
    
                window.addEventListener('load', function () {
    const preloader = document.getElementById('preloader');
    const mainContent = document.getElementById('main-content');

    preloader.style.opacity = '0'; 

    setTimeout(function () {
    preloader.style.display = 'none';  
    mainContent.style.visibility = 'visible'; 
    mainContent.style.opacity = '1'; 
}, 900);
});

</script>



</script>
    

    
    
    <main>
    
            


                        <!--  CARRUSEL   -->
                        <!--  CARRUSEL   -->
                        <!--  CARRUSEL   -->

                        <main id="main-content" style="opacity: 0; transition: opacity 0.9s;">  
                        <div class="main-container">
    <!-- Título -->
    <h2 class="carousel-title">Ofertas Destacadas</h2>
    </div>

    <!-- Contenedor -->
    <?php
        
        $queryCarrusel = "SELECT id, foto FROM autoactualizado WHERE id > 100";  
        $resultadoCarrusel = mysqli_query($conexion, $queryCarrusel);

        if (!$resultadoCarrusel) {
            die("Error en la consulta: " . mysqli_error($conexion));
        }
    ?>

    <div class="carousel-container" id="carousel">
        <?php while ($filaCarrusel = mysqli_fetch_assoc($resultadoCarrusel)) { ?>
            <div class="carousel-slide">
                <a href="ventanacomprarauto.php?id=<?php echo $filaCarrusel['id']; ?>">  <!-- Usa el id correcto -->
                    <img src="<?php echo $filaCarrusel['foto']; ?>" alt="Imagen del auto">
                </a>
            </div>
        <?php } ?>
    </div>
</div>

                    

                            <script>
                                //MOVIMIENTO CARRUSEL
    function autoScrollCarousel() {
        const carousel = document.getElementById('carousel');
        const slideWidth = carousel.clientWidth;  // Ancho de cada slide
        let currentIndex = 0;
    
    function updateSlides() {
        const slides = document.querySelectorAll('.carousel-slide');
        const totalSlides = slides.length;

            setInterval(() => {
                currentIndex += 1;

                
                if (currentIndex >= totalSlides) {
                    currentIndex = 0;
                }

            
                carousel.scrollTo({
                    left: slideWidth * currentIndex,
                    behavior: 'smooth'
                });
            },  3000);
        }

                
            window.addEventListener('load', updateSlides);
            }

            
            autoScrollCarousel();

                                
                                //BOTON DE FILTRO POR MARCA
                                
                                function filtrarPorMarca(marca) {
    const cartas = document.querySelectorAll('.card');

    cartas.forEach(carta => {
        const marcaCarta = carta.getAttribute('data-marca');

        if (marca === "" || marcaCarta.includes(marca)) { 
            carta.style.display = "block";
        } else {
            carta.style.display = "none";
        }
    });
}

    //CARGA DE CARTAS AL CARGAR LA PÁGINA

    window.onload = function () {
    ajustarCartas();
};

function ajustarCartas() {
    const cartas = document.querySelectorAll('.card');

    cartas.forEach(carta => {
        carta.style.display = "block"; 
    });
}

document.addEventListener("DOMContentLoaded", function() {
     
    const cartas = document.querySelectorAll('.card');
    cartas.forEach(carta => {
        carta.style.display = 'block';
    });
});


        </script>

<!--  CARRUSEL   -->


        

                        <!-- MITSUBISHI -->
    <button onclick="filtrarPorMarca('Mitsubishi')" class="logo-button">
        <img src="https://www.svgrepo.com/show/446903/mitsubishi.svg" class="logo-img" alt="Pagani">
    </button>
    
                        <!-- TOYOTA -->
    <button onclick="filtrarPorMarca('Toyota')" class="logo-button">
        <img src="https://www.svgrepo.com/show/306868/toyota.svg" class="logo-img" alt="Toyota">
    </button>

                        <!-- FORD -->
    <button onclick="filtrarPorMarca('Ford')" class="logo-button">
        <img src="https://www.svgrepo.com/show/330460/ford.svg" class="logo-img" alt="Ford">
    </button>
                        <!-- TODOS -->
    <button onclick="filtrarPorMarca('')" class= "logo-button">
        <img src="https://www.svgrepo.com/show/500472/back.svg" class="logo-img" alt="todos"> </button>
</div>


                <!-- CARTA DE PRODUCTO -->
                <!-- CARTA DE PRODUCTO -->
                <!-- CARTA DE PRODUCTO -->

     
                <div class="card-container">
                    <?php
                    while($fila = mysqli_fetch_assoc($resultado)){ ?>
                        
                       
                        <div class="card" data-marca="<?php echo $fila['nombre']; ?>">
                        <div class="card-img">
                        <img   src="<?php echo  $fila['foto'] ?> " height="auto" width="100%" alt="Renault Clio V6" class="alinear-derecha">
                        </div>

                        <div  class="card-title"> <?php echo $fila["nombre"] ?> </div>
                        
                        <div class="card-subtitle"> <?php echo $fila["kilometraje"] ?> km </div>
                        <hr class="card-divider">
                       
                        <div class="card-footer">
                            <div class="card-price"><span>$</span> <?php echo $fila["precio"] ?> </div>
                            <button class="card-btn">
                                 <a href="ventanacomprarauto.php?id=<?php echo $fila['id']?>"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24">
                                    <path d="m397.78 316h-205.13a15 15 0 0 1 -14.65-11.67l-34.54-150.48a15 15 0 0 1 14.62-18.36h274.27a15 15 0 0 1 14.65 18.36l-34.6 150.48a15 15 0 0 1 -14.62 11.67zm-193.19-30h181.25l27.67-120.48h-236.6z"></path>
                                    <path d="m222 450a57.48 57.48 0 1 1 57.48-57.48 57.54 57.54 0 0 1 -57.48 57.48zm0-84.95a27.48 27.48 0 1 0 27.48 27.47 27.5 27.5 0 0 0 -27.48-27.47z"></path>
                                    <path d="m368.42 450a57.48 57.48 0 1 1 57.48-57.48 57.54 57.54 0 0 1 -57.48 57.48zm0-84.95a27.48 27.48 0 1 0 27.48 27.47 27.5 27.5 0 0 0 -27.48-27.47z"></path>
                                    <path d="m158.08 165.49a15 15 0 0 1 -14.23-10.26l-25.71-77.23h-47.44a15 15 0 1 1 0-30h58.3a15 15 0 0 1 14.23 10.26l29.13 87.49a15 15 0 0 1 -14.23 19.74z"></path>
                                </svg>
                            </a>
                                </button>
                        </div>
                    </div>
                 
                    <?php
                    
                }
                    ?>
                          

            <footer>
                        <div class="footer-container">
                            <div class="footer-section">
                                <h3>Acerca de Nosotros</h3>
                                <p>MotorTown es una plataforma líder en la venta de autos. Ofrecemos una amplia variedad de vehículos de las mejores marcas con ofertas exclusivas y financiamiento disponible.</p>
                            </div>
                    
                            <div class="footer-section">
                                <h3>Enlaces Rápidos</h3>
                                <ul>
                                    <li><a href="/menuPrincipal29oct.php">Inicio</a></li>
                                    <li><a href="crear_cuenta.php">Registrarse</a></li>
                                    <li><a href="iniciar_sesion29oct.php">Iniciar Sesión</a></li>
                                    </ul>
                            </div>
                    
                            <div class="footer-section">
                                <h3>Contáctenos</h3>
                                <ul>
                                    <li><i class="fas fa-map-marker-alt"></i> Av. de los Constituyentes 5880, CABA</li>
                                    <li><i class="fas fa-phone-alt"></i> Teléfono: +123 456 7890</li>
                                    <li><i class="fas fa-envelope"></i> Email: info@motortown.com</li>
                                </ul>
                            </div>
                    
                        
                        </div>
                    
                        <div class="footer-bottom">
                            <p>&copy; 2024 MotorTown. Todos los derechos reservados.</p>
                        </div>
                    </footer>





</body>
</html>


<center>





