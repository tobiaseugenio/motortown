
<?php
    $servername = "127.0.0.1";
    $database = "motortown";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); 

    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
         
        $query = "select * from autoactualizado where id='".$_GET['id']."'";
        $resultado=mysqli_query($conexion, $query);
    }

    

    ?>
        

<!DOCTYPE html>

<link rel="stylesheet" href="ventanacomrarauto_actualizado 1.css">

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra de Autos - Detalles del Producto</title>
    <style>
        
        
    </style>
</head>
<body>
    <div class="container">

    <?php
                    while($fila = mysqli_fetch_assoc($resultado)){ ?>
    <img   src="<?php echo  $fila['foto'] ?> " alt="Auto en venta" class="product-image">
        
        <div class="product-title"> <?php echo $fila["nombre"] ?> </div>
        
        
        <div class="product-price"> <span>$</span> <?php echo $fila["precio"] ?></div>
        
        <?php
            if($fila["stock"]){
                ?>
                <a href="#compra" class="buy-button" onclick="mostrarPopup()">Comprar Ahora</a>
            
                <?php
            }
            else{
                ?>
                <a href="#compra" class="buy-button" >No disponible</a>
                <?php
            }
                ?>

        <div class="description">
            <h2>Descripción</h2>
            <p> <?php echo $fila["descripcion"] ?> </div>

        <div class="features">
            <h2>Características</h2>
            <ul>
                <li><img src="https://www.svgrepo.com/show/533389/calendar-days.svg" alt="Año" class="feature-img"> Año: <?php echo $fila["anio"] ?>  </li>
               
               
                <li><img src="https://www.svgrepo.com/show/391029/odometer.svg" alt="Kilometraje" class="feature-img"> Kilometraje: <?php echo $fila["kilometraje"] ?> km</li>
               
               
                <li><img src="https://www.svgrepo.com/show/237162/engine-motor.svg" alt="Motor" class="feature-img"> Motor: <?php echo $fila["motor"] ?> </li>
               
               
                <li><img src="https://www.svgrepo.com/show/237143/gearshift.svg" alt="Transmisión" class="feature-img"> Transmisión: <?php echo $fila["transmision"] ?></li>
            </ul>
        </div>

    </div>
                <?php            
                    }
                    ?>


    <div class="popup-overlay"></div>
    <div class="popup" id="popup">
        <h2>La compra se ha realizado correctamente</h2>
        <?php
        $res = "update autoactualizado set stock = 0 where id='".$_GET['id']."'";
          mysqli_query($conexion, $res);
        ?> 
        <button onclick="cerrarPopup()">Cerrar</button>
    </div>

    <script>
        function mostrarPopup() {
            document.getElementById('popup').classList.add('show');
            document.querySelector('.popup-overlay').classList.add('show');
        }

        function cerrarPopup() {
            document.getElementById('popup').classList.remove('show');
            document.querySelector('.popup-overlay').classList.remove('show');
            location.reload(true);
        }
    </script>

</body>
</html>

