<?php
$error_message = '';  

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $mailusuario = $_POST["mailusuario"] ?? null;
    $password = $_POST["contrasenia"] ?? null;

    if (!$mailusuario or !$password) {
        $error_message = "Correo electrónico y contraseña son requeridos.";
    } else {
         
        $valid_domains = ['gmail.com', 'yahoo.com', 'hotmail.com'];
        if (!filter_var($mailusuario, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Por favor, ingresa una dirección de correo electrónico válida.";
        } elseif (!preg_match('/@(' . implode('|', $valid_domains) . ')$/i', $mailusuario)) {
            $error_message = "El correo debe ser de un dominio válido como @gmail.com, @yahoo.com o @hotmail.com.";
        } else {
             
            $servername = "127.0.0.1";
            $database = "motortown";
            $username = "alumno";
            $db_password = "alumnoipm";

            $conexion = mysqli_connect($servername, $username, $db_password, $database);

            if (!$conexion) {
                die("Conexión fallida: " . mysqli_connect_error());
            }

            
            $query = "SELECT contrasenia FROM usuario WHERE mailusuario = ?";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "s", $mailusuario);
            mysqli_stmt_execute($stmt);
            $resultado = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($resultado) > 0) {
                 
                $error_message = "Este correo ya está registrado.";
            } else {
                 
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                 
                $nombre = ''; 
                $insert_query = "INSERT INTO usuario (nombre, contrasenia, mailusuario) VALUES (?, ?, ?)";
                $insert_stmt = mysqli_prepare($conexion, $insert_query);
                mysqli_stmt_bind_param($insert_stmt, "sss", $nombre, $hashed_password, $mailusuario);
                    
                if (mysqli_stmt_execute($insert_stmt)) {
                     
                    session_start();
                    $_SESSION["usuario"] = $nombre;
                    header("Location: /menuPrincipal29oct.php");
                    exit();
                } else {
                    $error_message = "Error al registrar el usuario.";
                }
            }

            mysqli_close($conexion);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear cuenta</title>
    <link rel="stylesheet" href="crearCuenta_actualizado.css">
</head>
<body>
    <center>
        <header>
            <h4>
                <img src="imagenes/logomotortownsinfondo.png" height="117" alt="Logo">
            </h4>
        </header>

        <div class="form-box">
             
            <?php if ($error_message): ?>
                <div class="error-message" style="color: red;">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <form class="form" method="POST" action="crear_cuenta.php">
                <span class="title">Crear cuenta</span>
                <div class="form-container">
                    <input type="email" name="mailusuario" class="input" placeholder="Correo electrónico" required>
                    <input type="password" name="contrasenia" class="input" placeholder="Contraseña" required>
                </div>
                <button type="submit">Crear cuenta</button>
            </form>

            <div class="form-section">
                <p>Tenés una cuenta? <a href="iniciar_sesion29oct.php">Iniciar sesión</a></p>
            </div>
        </div>
    </center>
</body>
</html>
