create table autoactualizado (
id int primary key,
foto text,
nombre varchar(45),
kilometraje int,
precio float,
descripcion longtext,
anio int,
motor varchar(45),
transmision varchar(45)
);

create table usuario (
id int primary key,
mailusuario varchar(45),
contrasenia varchar(45)
);



insert into autoactualizado values(1, "imagenes/RenaultClioV6.jpg" , "Renault Clio V6" , 0, 50000, "Vende Renault Clio V6, un compacto deportivo que combina diseño audaz con un potente motor V6 de 3.0 litros. Con una aceleración impresionante y un manejo ágil, este modelo ofrece una experiencia de conducción emocionante. Equipado con un interior bien cuidado y detalles únicos, es perfecto para los amantes de la velocidad y la exclusividad. ¡No pierdas la oportunidad de tener este icónico hatchback en tus manos!", "2001", "2.9L V6" , "6 Marchas Manual");

insert into autoactualizado values(2, "imagenes/paganiZondaC12.jpg", "Pagani Zonda S" , 0 , 900000, "Superdeportivo exclusivo con motor V12 de 7.3 litros y 550 CV. Acelera de 0 a 100 km/h en 3.7 segundos. Diseño aerodinámico en fibra de carbono, ofreciendo ligereza y precisión en el manejo. Interiores de lujo con acabados artesanales. Una obra de arte en movimiento, ideal para los verdaderos entusiastas" , "2002", "V12 7.3L" , "6 Velocidades Manual" );

insert into autoactualizado values(3, "imagenes/3000gt.jpg" , "Mitsubishi 3000GT VR4", 52000, 30000, "¡Un clásico de los 90 que sigue dando guerra! Este 3000GT VR4 viene con un motor V6 biturbo de 320 CV y tracción integral para una conducción emocionante. Tiene toda la tecnología avanzada de la época, como suspensión activa y aerodinámica ajustable. Si buscas un deportivo potente y con mucho estilo, este es el indicado. Ideal para amantes de lo retro y la velocidad.", "1999", "3L V6", "5 Marchas manual");

insert into autoactualizado values(4, "imagenes/zafira.jpg", "Chevrolet Zafira", 100000, 2000, "Monovolumen práctico y listo para la familia. Espaciosa, cómoda y con un motor que sigue rindiendo. ¡Con 100,000 km, todavía tiene mucho para dar en tus próximos viajes!", "1999", "4l 1.3", "5 marchas manual");

insert into autoactualizado values(5, "imagenes/toyotaMR2.jpg" , "Toyota MR2" , 4350 , 12000, "Este Toyota MR2 es una joya para los amantes de los deportivos compactos. Con solo 4,350 km recorridos, prácticamente está nuevo. Es ágil, divertido y súper ligero, gracias a su motor central de 1.8 litros que entrega una respuesta impresionante en cada curva. La tracción trasera te garantiza una experiencia de manejo emocionante, ideal para disfrutar al máximo en cada salida. El diseño sigue siendo un clásico, con líneas deportivas y ese toque retro que nunca pasa de moda. Además, con tan pocos kilómetros, este MR2 es difícil de encontrar en estas condiciones. ¡Perfecto para quien busca un deportivo único y con historia!", "2005", "4 cilindros en linea, 1.8 litros" , "Manual 6 velocidades");


insert into autoactualizado values(6, "imagenes/isuzu-piazza.jpg" , "Isuzu Piazza" , 2010 , 5000, "¡Un clásico que no pasa de moda! Este Isuzu Piazza tiene solo 2,010 km y está en excelente estado. Con su diseño distintivo y motor ágil, es ideal para quienes buscan un auto único y divertido. Perfecto para darle un toque retro a tus paseos." , "1981" , "2L 4 cilindros en linea" , "4 marchas automático" );


insert into autoactualizado values(7, "imagenes/fordgt.jpg" , "Ford GT" , 500, 300000, "Presentamos este excepcional Ford GT del año 2005, con solo 500 km recorridos, que ofrece una combinación perfecta de rendimiento y diseño icónico. Equipado con un potente motor V8 de 5.4 litros sobrealimentado, este superdeportivo entrega una impresionante potencia y aceleración. Su aerodinámica cuidadosamente diseñada no solo realza su atractivo visual, sino que también mejora la estabilidad a altas velocidades. Con interiores de lujo y tecnología de vanguardia, este Ford GT es una verdadera obra maestra automovilística. Ideal para coleccionistas y entusiastas que buscan un vehículo de alto rendimiento en estado casi nuevo." , "2005" , "V8 5.4L" , "6 velocidades" );



insert into autoactualizado values(8, "imagenes/Toyota-chaser.jpg" , "Toyota Chaser" , 910, 32000 , "Descubre este impresionante Toyota Chaser con solo 910 km recorridos. Este sedán deportivo combina un diseño elegante y un rendimiento excepcional. Su motor potente ofrece una experiencia de conducción emocionante, mientras que su interior espacioso y cómodo lo convierte en una opción perfecta tanto para paseos como para el día a día. Con tan pocos kilómetros, este Chaser es una rareza que no querrás perderte, ideal para los entusiastas de los autos que buscan un clásico moderno." , "1996" , "3L I6" , "5 Marchas, manual" );

insert into autoactualizado values(120, "imagenes/Toyota-chaser.jpg" , "Toyota Chaser" , 910, 32000 , "Descubre este impresionante Toyota Chaser con solo 910 km recorridos. Este sedán deportivo combina un diseño elegante y un rendimiento excepcional. Su motor potente ofrece una experiencia de conducción emocionante, mientras que su interior espacioso y cómodo lo convierte en una opción perfecta tanto para paseos como para el día a día. Con tan pocos kilómetros, este Chaser es una rareza que no querrás perderte, ideal para los entusiastas de los autos que buscan un clásico moderno." , "1996" , "3L I6" , "5 Marchas, manual" );


insert into autoactualizado values(9, "imagenes/GolfMk5.jpg" , "Volkswagen Golf ¡Conoce este genial Volkswagen Golf MK5 con solo 5,000 km! Es el auto perfecto para quienes buscan estilo y practicidad. Con su diseño moderno y espacioso interior, es ideal para cualquier aventura, ya sea un viaje por la ciudad o una escapada de fin de semana. Su manejo es ágil y cómodo, y la eficiencia del motor te permitirá ahorrar en cada viaje. Con tan pocos kilómetros, este Golf está listo para acompañarte en muchos más. " , 5000, 10000, "descripcion" , 2010 , "4 Cilindros 2.0L" );

insert into autoactualizado values(10,"imagenes/porsche912.jpg" , "Porsche 912" , 2018 , 45000, "Presentamos este magnífico Porsche 912, un verdadero clásico con solo 2,018 km recorridos. Este modelo icónico combina el estilo atemporal de Porsche con un rendimiento excepcional, gracias a su motor de cuatro cilindros que ofrece una experiencia de conducción única. La elegancia de su diseño exterior y el cuidado en los detalles del interior reflejan la calidad y artesanía que caracterizan a la marca. Este Porsche 912 ha sido meticulosamente mantenido y es una adición valiosa para cualquier colección de autos clásicos. Ideal para entusiastas que buscan un vehículo que encarna la esencia de la automoción de los años 60, este 912 es una oportunidad imperdible para poseer un pedazo de historia automovilística." , "1965" , "1.6 Litros Boxer 4 cilindros"  );

insert into autoactualizado values(11 , "imagenes/toyotaG86.webp" , "Toyota GT86", 50000, 5000, "esto es un toyota gt86" , "2015" , "2.0L Boxer 4 cilindros" , "6 Marchas automático" );

INSERT INTO autoactualizado VALUES (12, "imagenes/corvette_c5.jpeg", 'Chevrolet Corvette C5', 75000, 25000, "Este Corvette C5 2002 es el equilibrio perfecto entre rendimiento y diseño icónico. Equipado con un potente motor V8 LS1, entrega una experiencia de conducción emocionante, con una aceleración y manejo que hacen honor a la leyenda Corvette. Su diseño aerodinámico y elegante sigue siendo un símbolo de estilo, mientras que el interior ofrece comodidad y tecnología para el conductor. Perfecto para quienes buscan un deportivo clásico americano con potencia y personalidad." , 2002, '5.7L V8', 'Manual');  

INSERT INTO autoactualizado VALUES (101, 'imagenes/lotus_elise.jpg', 'Lotus Elise', 45000, 28000, "Ligero, ágil y diseñado para la pista, este Lotus Elise 1996 es una verdadera obra maestra de ingeniería británica. Con su chasis de aluminio y su motor eficiente, ofrece una experiencia de manejo pura y emocionante. Su diseño aerodinámico y minimalista refleja su enfoque en el rendimiento, mientras que el interior, centrado en el conductor, te conecta directamente con la carretera. Ideal para los amantes de los deportivos que valoran la precisión y el diseño icónico de Lotus." , 1996, '1.8L I4', '5 Marchas Manual');  

INSERT INTO autoactualizado VALUES (15, 'imagenes/bronco.jpeg', 'Ford Bronco', 120000, 18500, "Robusta y lista para la aventura, esta Ford Bronco 1996 es un clásico todoterreno con carácter. Su diseño imponente y su tracción en las cuatro ruedas la hacen perfecta para cualquier terreno, desde la ciudad hasta caminos más desafiantes. Con un interior espacioso y cómodo, es ideal para viajes largos o escapadas de fin de semana. Un ícono americano que combina versatilidad, potencia y estilo atemporal." , 1996, '5.0L V8', 'Manual de 5 marchas');  


INSERT INTO autoactualizado VALUES (13, 'imagenes/trans_am.webp', 'Pontiac Trans Am', 65000, 21000, "Este Pontiac Trans Am 2001 es un muscle car que combina potencia y estilo atemporal. Equipado con un motor V8 LS1, ofrece un rendimiento impresionante y una experiencia de manejo emocionante. Su diseño audaz, con el icónico capó esculpido y líneas agresivas, refleja su carácter deportivo. El interior cómodo y bien equipado asegura que cada viaje sea placentero, ya sea en la ciudad o en carretera. Ideal para entusiastas de los autos clásicos americanos que buscan un vehículo con alma y carácter." , 2001, '5.7L V8', 'Automática');  

INSERT INTO autoactualizado VALUES (10, 'imagenes/mx5nd.jpg', 'Mazda MX-5 ND', 30000, 28000, "El Mazda MX-5 ND es el epítome del roadster moderno: ligero, ágil y lleno de diversión al volante. Con su motor eficiente y tracción trasera, ofrece una experiencia de conducción pura que conecta al conductor con la carretera. Su diseño elegante y deportivo, junto con un interior enfocado en la simplicidad y el confort, hacen de este MX-5 la opción ideal para quienes buscan un auto que combine rendimiento, estilo y placer de conducción. Perfecto para quienes disfrutan de un manejo dinámico y abierto." ,2020, '2.0L I4', 'Manual de 6 marchas');  
