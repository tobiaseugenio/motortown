<?php
$error_message = ''; 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $mailusuario = $_POST["mailusuario"] ?? null;
    $password = $_POST["contrasenia"] ?? null;

    if (!$mailusuario || !$password) {
        $error_message = "Correo electrónico y contraseña son requeridos.";
    } else {
         
        $valid_domains = ['gmail.com', 'yahoo.com', 'hotmail.com'];
        if (!filter_var($mailusuario, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Por favor, ingresa una dirección de correo electrónico válida.";
        } elseif (!preg_match('/@(' . implode('|', $valid_domains) . ')$/i', $mailusuario)) {
            $error_message = "El correo debe ser de un dominio válido como @gmail.com, @yahoo.com o @hotmail.com.";
        } else {
             
            $servername = "127.0.0.1";
            $database = "motortown";
            $username = "alumno";
            $db_password = "alumnoipm";

            $conexion = mysqli_connect($servername, $username, $db_password, $database);

            if (!$conexion) {
                die("Conexión fallida: " . mysqli_connect_error());
            }

             
            $query = "SELECT contrasenia, nombre FROM usuario WHERE mailusuario = ?";
            $stmt = mysqli_prepare($conexion, $query);
            mysqli_stmt_bind_param($stmt, "s", $mailusuario);
            mysqli_stmt_execute($stmt);    
            $resultado = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($resultado) == 0) {
                $error_message = "Mail incorrecto.";
            } else {
                
                $fila = mysqli_fetch_assoc($resultado);
                if (password_verify($password, $fila["contrasenia"])) {
                    session_start();
                    $_SESSION["usuario"] = $fila["nombre"];
 
                    header("Location: /menuPrincipal29oct.php");
                    exit();
                } else {
                    $error_message = "Contraseña incorrecta.";
                }
            }

            mysqli_close($conexion);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <link rel="stylesheet" href="crearCuenta_actualizado.css">
</head>
<body>
    <center>
        <header>
            <h4>
                <img src="imagenes/logomotortownsinfondo.png" height="117" alt="Logo">
            </h4>
        </header>

        <div class="form-box">
             
            <?php if ($error_message): ?>
                <div class="error-message" style="color: red;">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <form class="form" method="POST" action="iniciar_sesion29oct.php">
                <span class="title">Iniciar Sesión</span>
                <div class="form-container">
                    <input type="email" name="mailusuario" class="input" placeholder="Correo electrónico" required>
                    <input type="password" name="contrasenia" class="input" placeholder="Contraseña" required>
                </div>
                <button type="submit">Iniciar sesión</button>
            </form>

            <div class="form-section">
                <p>No tenés una cuenta? <a href="crear_cuenta.php">Registrarse</a></p>
            </div>
        </div>
    </center>
</body>
</html>
